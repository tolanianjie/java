package oopsconcepts;

public class CreateObjectsUsingNew {

	String name = "Hello World!";
	public static void main(String[] args) {
		CreateObjectsUsingNew obj = new CreateObjectsUsingNew();
		System.out.println("Message: "+obj.name);
	}
}
