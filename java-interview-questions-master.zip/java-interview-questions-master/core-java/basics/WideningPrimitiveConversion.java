package basics;

public class WideningPrimitiveConversion {

	public static void main(String[] args) {
		System.out.println("Y" + "O");
		System.out.println('A');

	}

}
