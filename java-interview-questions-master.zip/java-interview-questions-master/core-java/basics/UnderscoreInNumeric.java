package basics;

public class UnderscoreInNumeric {

	public static void main(String[] args) {
		int num = 1_00_00_000;
		System.out.println("Inum: "+num);
	}
}
